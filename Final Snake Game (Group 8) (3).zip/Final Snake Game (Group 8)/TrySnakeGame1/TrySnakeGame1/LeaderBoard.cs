﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using Timer = System.Timers.Timer;
using System.Media;
using System.IO;

namespace SnakeGame_Group8_
{
    class user// Encapsulation
    {
        //private attribute
        private string name;// user ingame name
        private int score;//score of the user 

        // properties
        public string Username
        {
            get { return name; }
            set { name = value; }
        }
        public int Score
        {
            get { return score; }
            set { score = value; }

        }

    }




    class LeaderBoard
    {


        public void check_file()
        {
            try
            {
                FileStream fs = File.Open("Score.txt", FileMode.Open);
                fs.Close();
            }
            catch (UnauthorizedAccessException ts)
            {

                Console.WriteLine("Invalid: {0}", ts);
            }
            catch (FileNotFoundException ts)
            {
                Console.WriteLine("{0}", ts);

            }
        }
        public void Show()
        {
            try
            {

                Dictionary<string, int> name_score = new Dictionary<string, int>();


                FileStream fs = File.OpenRead("Score.txt");
                string[] content = File.ReadAllLines("Score.txt");
                int ctr = 0;

                foreach (string element in content)
                {



                    string[] array_line_split = element.Split(',');
                    bool keyExist = name_score.ContainsKey(array_line_split[0]);
                    if (keyExist)
                    {
                        name_score[array_line_split[0]] = int.Parse(array_line_split[1]);

                    }
                    else
                    {
                        name_score.Add(array_line_split[0], int.Parse(array_line_split[1]));
                    }


                    ctr++;
                }





                try
                {
                    Console.SetCursorPosition((Console.WindowWidth - 10) - 20, 0);
                    Console.WriteLine("Top 10");
                    var ordered = name_score.ToList();
                    ordered.Sort((pair1, pair2) => pair1.Value.CompareTo(pair2.Value));
                    ordered.Reverse();
                    int i = 0;
                    Console.SetCursorPosition((Console.WindowWidth - 10) - 20, 2);
                    foreach (KeyValuePair<string, int> value in ordered)
                    {

                        if (i < 10)
                        {
                            Console.SetCursorPosition((Console.WindowWidth - 10) - 20, i + 1);


                            Console.WriteLine(value.Key + ": " + Convert.ToString(value.Value));
                            i++;
                        }


                        else
                            break;


                    }
                    fs.Close();


                }
                catch
                {
                    Console.WriteLine("The problem is in the printing!");
                }


            }
            catch
            {
                Console.WriteLine("Sa pag aadd sa array yung error");
            }

        }



        public void addScore(string name, int number)
        {
            user User = new user();
            //SET
            User.Username = name;
            User.Score = number;
            //GET
            using (StreamWriter writer = new StreamWriter("Score.txt", true))
            {
                writer.WriteLine(User.Username + "," + Convert.ToString(User.Score));
            }






        }
        public string name(string msg)
        {
            string nammes;
            Console.Write(msg);
            nammes = Console.ReadLine();

            return nammes;

        }
    }
}
