﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Timer = System.Timers.Timer;
using System.Media;
using System.IO;


namespace SnakeGame_Group8_
{

    public class Program : Level_Snake
    {

        #region Methods
        static bool proceed = true;
        public List<int> CoordinatesX = new List<int>();
        public List<int> CoordinatesY = new List<int>();
        static int IterationCount = 0;
        static int score = 0;
        static int X = Console.WindowWidth;
        static int Y = Console.WindowHeight;
        static int a;
        static int b;



        static int SegmentsCount = 1;
        static Random random = new Random();
        static ConsoleKey key;
        static ConsoleKey helper;
        public void displayScore(int score) // displays score
        {
            Console.WriteLine("           SCORE: {0} ", score);

        }

        public void displayGameDetails(int level, int score)
        {
            Console.SetCursorPosition((Console.WindowWidth / 2) - 10, 0);
            Console.WriteLine("_____LEVEL " + level + "_____");
            Console.SetCursorPosition((Console.WindowWidth / 2) - 17, 1);

            displayScore(score);
        }


        public void time() // DISPLAYS time
        {
            Console.SetCursorPosition((Console.WindowWidth / 2) - 2, 1);
            // Dito lalagay yung timer

            //Timer.Timers(seconds);
            //Console.WriteLine("     Time left: {0} ", seconds);
            //int numberofSeconds = 1;
            //Timer.Timers(numberofSeconds);
        }


        public void Food(int border1 = 2, int border = 3) //generates food
        {


            a = random.Next(2, Console.WindowWidth / border1 - border); // generates random coordinate for food a (a = X) into Scene()
            b = random.Next(4, Console.WindowHeight / border1 - border); // generates random coordinate for food b (b = Y) into Scene()


            if (a == X && b == Y)// prevents the random from generating the same coordinates as X and Y 
            {
                Food();
            }



            for (int k = 0; k <= SegmentsCount + 1; k++) // prevents from generating the food into snake's body and one tile behind the snake
            {
                if ((IterationCount - k) - 1 >= 0) // CoordinatesX[] and CoordinatesY[] are not defined during the first tile, and the IterationCount = 0
                {
                    if (a == CoordinatesX[(IterationCount - k) - 1] && b == CoordinatesY[(IterationCount - k) - 1]) // Coordinates are of the snake's current position and one tile behind it 
                    {
                        // Gameover kapag na touch yung snake yung body niya.
                        Food();
                        GameOver();// generating is repeated
                    }
                }

            }
            Console.SetCursorPosition(a, b); // sets cursor to the place of the food
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.Write("♦");//Writes into the console

            /*public void Food2()
            {
                c = random.Next(1, Console.WindowWidth / 2 - 3); // generates random coordinate for food c (c = Q) into Scene()
                d = random.Next(3, Console.WindowHeight / 2 - 3); // generates random coordinate for food d (d = W) into Scene()

                if (c == Q && d == W)// prevents the random from generating the same coordinates as Q and W 
                {
                    Food2();
                }

                for (int j = 0; j <= SegmentsCount + 1; j++) // prevents from generating the food into snake's body and one tile behind the snake
                {
                    if ((IterationCount - j) - 1 >= 0) // CoordinatesX[] and CoordinatesY[] are not defined during the first tile, and the IterationCount = 0
                    {
                        if (c == CoordinatesX[(IterationCount - j) - 1] && d == CoordinatesY[(IterationCount - j) - 1]) // Coordinates are of the snake's current position and one tile behind it 
                        {
                            // Gameover kapag na touch yung snake yung body niya.
                            Food2();
                            GameOver();// generating is repeated
                        }
                    }
                }
                Console.SetCursorPosition(c, d); // sets cursor to the place of the food
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("@");//Writes into the console*/


        }
        //for levels
        public void FoodEaten()
        {
            LeaderBoard lb = new LeaderBoard();
            if (a == X && b == Y)  // food coordinates = snake coordinates


            {

                if (SegmentsCount == 1) // during the first eating, the beep is played only during longer sleeping
                {
                    Console.Beep(7000, 100);
                }
                Console.Beep(7000, 70);

                //mag ceclear ung console kada level laging -100 bago magiba ng level
                if (score == 200 || score == 500 || score == 800 || score == 1100 || score == 1500 || score == 1900 || score == 2300 || score == 2700 || score == 3100 || score == 3500)
                {
                    Console.Clear();
                }

                score = score + 100;
                if (score < 300) //level 1
                {

                    displayGameDetails(1, score);
                    Food();

                }
                else if (score == 300 || score < 600) // level 2 
                {
                    
                    Food(2, 2);
                    Scene2();
                    displayGameDetails(2, score);
                    lb.Show();

                }
                else if (score == 600 || score < 900) // level 3
                {
                    Food(2, 0);
                    Scene3();
                    displayGameDetails(3, score);
                    lb.Show();
                }
                else if (score == 900 || score < 1200) //level 4
                {
                    Food(2, -1);
                    Scene4();
                    displayGameDetails(4, score);
                    lb.Show();
                }
                else if (score == 1200 || score < 1600) //level 5
                {
                    Food(2, -5);
                    Scene5();
                    displayGameDetails(5, score);
                    lb.Show();

                }
                else if (score == 1600 || score < 2000) // level 6
                {
                    Food(2, -7);
                    Scene6();
                    displayGameDetails(6, score);
                    lb.Show();
                }
                else if (score == 2000 || score < 2400) // level 7
                {
                    Food(2, -9);
                    Scene7();
                    displayGameDetails(7, score);
                    lb.Show();
                }
                else if (score == 2400 || score < 2800) // level 8
                {
                    Food(2, -10);
                    Scene8();
                    displayGameDetails(8, score);
                    lb.Show();
                }
                else if (score == 2800 || score < 3200) // level 9//
                {
                    Food(2, -13);
                    Scene9();
                    displayGameDetails(9, score);
                    lb.Show();
                }
                else if (score == 3200 || score < 36000) // level 10//
                {
                    Food(2, -14);
                    Scene10();
                    displayGameDetails(10, score);
                    lb.Show();
                    Congratulations();

                }

                SegmentsCount++;

            }

        }


        public void BorderIntro() // creates the play Scene
        {

            //Dito yung lines ng border pero hindi siya nateterminate nakakin lang siya nung snake
            Console.ForegroundColor = ConsoleColor.Red;
            for (int x = 1; x < Console.WindowWidth; x++)
            {
                Console.SetCursorPosition(x, Console.WindowHeight - 1); //writting bottom limit
                Console.Write("↔");
                Console.SetCursorPosition(x, 2);//writting top limit
                Console.Write("↔");
            }
            for (int y = 2; y < Console.WindowHeight; y++)
            {
                Console.SetCursorPosition(Console.WindowWidth - 1, y);//writting bottom limit
                Console.Write("↕");
                Console.SetCursorPosition(0, y);//writting top limit
                Console.Write("↕");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
        }

        public void Move(int border1, int border, int level = 1)
        {

            //Eating snake naappend sa list yung mga nakain na foods

            CoordinatesX.Add(X); // adds into the list the current coordinate
            CoordinatesY.Add(Y); // adds into the list the current coordinate
            Console.SetCursorPosition(X, Y); // sets the cursor to the current coordinates
            IterationCount++;
            Console.Write("O");
            if ((IterationCount - SegmentsCount) - 2 >= 0) // the first two iterations of this method are just the snake body loading = there's nothing to remove     
            {
                Console.SetCursorPosition(CoordinatesX[(IterationCount - SegmentsCount) - 2], CoordinatesY[(IterationCount - SegmentsCount) - 2]); // sets the cursor to the last segment of the snake 
                Console.Write(" "); // removes the "#" character, and the snake's body length is only of the SegmentsCount
                Console.SetCursorPosition(X, Y); // returns the cursor to the snake's head
            }
            for (int k = 0; k <= SegmentsCount; k++)
            {
                if ((IterationCount - k) - 2 >= 0) // the first two iterations of this method are just the snake body loading
                {
                    if (X == CoordinatesX[(IterationCount - k) - 2] && Y == CoordinatesY[(IterationCount - k) - 2]) // compares the current coordinates (snake's head) with coordinates of snake's body
                    {
                        GameOver();

                    }
                }
            }
            if (level == 3)
            {
                if (X == Console.WindowWidth / border1 - border || X == 0 || Y == Console.WindowHeight / border1 - border || Y == 2 || (X == 30 && Y == 14) || (X == 31 && Y == 13) || (X == 32 && Y == 12) || (X == 33 && Y == 11) || (X == 34 && Y == 10) || (X == 35 && Y == 9) || (X == 36 && Y == 8) || (X == 37 && Y == 7) || (X == 38 && Y == 6)) // compares the current coordinates (snake's head) with the play Scene
                                                                                                                                                                                                                                                                                                                                                         // dito sa if statement imomodify kung hanggang saan yung border
                {
                    GameOver();
                }
            }
            else if (level == 4)
            {
                if (X == Console.WindowWidth / border1 - border || X == 0 || Y == Console.WindowHeight / border1 - border || Y == 2 || (X == 5 && Y == 6) || (X == 6 && Y == 6) || (X == 7 && Y == 6) || (X == 8 && Y == 6) || (X == 12 && Y == 6) || (X == 13 && Y == 6) || (X == 14 && Y == 6) || (X == 15 && Y == 6) || (X == 8 && Y == 6) || (X == 19 && Y == 6) || (X == 20 && Y == 6) || (X == 21 && Y == 6) || (X == 22 && Y == 6)
                        || (X == 32 && Y == 12) || (X == 33 && Y == 12) || (X == 34 && Y == 12) || (X == 35 && Y == 12) || (X == 39 && Y == 12) || (X == 40 && Y == 12) || (X == 41 && Y == 12) || (X == 42 && Y == 12) || (X == 46 && Y == 12) || (X == 47 && Y == 12) || (X == 48 && Y == 12) || (X == 49 && Y == 12)
                    )
                {
                    GameOver();
                }
            }
            else if (level == 5)
            {
                if (X == Console.WindowWidth / border1 - border || X == 0 || Y == Console.WindowHeight / border1 - border || Y == 2 || (X == 6 && Y == 5) || (X == 6 && Y == 6) || (X == 6 && Y == 7) || (X == 6 && Y == 8) || (X == 6 && Y == 12) || (X == 6 && Y == 13) || (X == 6 && Y == 14) || (X == 6 && Y == 15) || (X == 6 && Y == 19) || (X == 6 && Y == 20) || (X == 6 && Y == 21) || (X == 6 && Y == 22)
                    || (X == 41 && Y == 14) || (X == 42 && Y == 13) || (X == 43 && Y == 12) || (X == 44 && Y == 11) || (X == 45 && Y == 10) || (X == 46 && Y == 9) || (X == 47 && Y == 8) || (X == 48 && Y == 7) || (X == 49 && Y == 6) || (X == 50 && Y == 5) || (X == 40 && Y == 15) || (X == 39 && Y == 16) || (X == 38 && Y == 17) || (X == 37 && Y == 18)
                    )

                {
                    GameOver();
                }
            }
            else if (level == 6)
            {
                if (X == Console.WindowWidth / border1 - border || X == 0 || Y == Console.WindowHeight / border1 - border || Y == 2 || (X == 6 && Y == 5) || (X == 6 && Y == 6) || (X == 6 && Y == 7) || (X == 6 && Y == 8) || (X == 6 && Y == 12) || (X == 6 && Y == 13) || (X == 6 && Y == 14) || (X == 6 && Y == 15) || (X == 6 && Y == 19) || (X == 6 && Y == 20) || (X == 6 && Y == 21) || (X == 6 && Y == 22) ||
                    (X == 32 && Y == 18) || (X == 33 && Y == 18) || (X == 34 && Y == 18) || (X == 35 && Y == 18) || (X == 39 && Y == 18) || (X == 40 && Y == 18) || (X == 41 && Y == 18) || (X == 40 && Y == 18) || (X == 42 && Y == 18) || (X == 46 && Y == 18) || (X == 47 && Y == 18) || (X == 48 && Y == 18) || (X == 49 && Y == 18) ||
                    (X == 30 && Y == 7) || (X == 31 && Y == 7) || (X == 32 && Y == 7) || (X == 33 && Y == 7) || (X == 38 && Y == 7) || (X == 39 && Y == 7) || (X == 40 && Y == 7) || (X == 41 && Y == 7) || (X == 45 && Y == 7) || (X == 46 && Y == 7) || (X == 47 && Y == 7) || (X == 48 && Y == 7)
                    )
                {
                    GameOver();
                }
            }
            else if (level == 7)
            {
                if (X == Console.WindowWidth / border1 - border || X == 0 || Y == Console.WindowHeight / border1 - border || Y == 2 || (X == 16 && Y == 17) || (X == 18 && Y == 15) || (X == 20 && Y == 13) || (X == 22 && Y == 11) || (X == 24 && Y == 9) || (X == 26 && Y == 7) || (X == 28 && Y == 5) ||
                    (X == 35 && Y == 18) || (X == 31 && Y == 18) || (X == 27 && Y == 18) || (X == 23 && Y == 18) || (X == 19 && Y == 18) || (X == 38 && Y == 17) || (X == 40 && Y == 15) || (X == 42 && Y == 13) || (X == 44 && Y == 11) ||
                    (X == 46 && Y == 9) || (X == 48 && Y == 7) || (X == 50 && Y == 5)
                    )
                {
                    GameOver();
                }
            }
            else if (level == 8)
            {
                if (X == Console.WindowWidth / border1 - border || X == 0 || Y == Console.WindowHeight / border1 - border || Y == 2 || (X == 5 && Y == 6) || (X == 6 && Y == 6) || (X == 7 && Y == 6) || (X == 8 && Y == 6) || (X == 12 && Y == 6) || (X == 13 && Y == 6) || (X == 14 && Y == 6) || (X == 15 && Y == 6) || (X == 19 && Y == 6) || (X == 20 && Y == 6) || (X == 21 && Y == 6) || (X == 22 && Y == 6) || (X == 30 && Y == 14) || (X == 31 && Y == 13) || (X == 32 && Y == 12) || (X == 33 && Y == 11) ||
                     (X == 5 && Y == 10) || (X == 5 && Y == 9) || (X == 5 && Y == 8) || (X == 5 && Y == 7) || (X == 5 && Y == 6))
                {
                    GameOver();
                }
            }
            else if (level == 9)
            {
                if (X == Console.WindowWidth / border1 - border || X == 0 || Y == Console.WindowHeight / border1 - border || Y == 2 || (X == 30 && Y == 14) || (X == 31 && Y == 14) || (X == 32 && Y == 14) || (X == 33 && Y == 14) || (X == 34 && Y == 14) || (X == 20 && Y == 20) || (X == 21 && Y == 21) || (X == 22 && Y == 22) || (X == 23 && Y == 23) || (X == 24 && Y == 24) ||
                    (X == 10 && Y == 15) || (X == 11 && Y == 15) || (X == 12 && Y == 15) || (X == 13 && Y == 15) || (X == 14 && Y == 15) || (X == 10 && Y == 7) || (X == 10 && Y == 8) || (X == 10 && Y == 9) || (X == 10 && Y == 10) || (X == 10 && Y == 11) ||
                    (X == 20 && Y == 12) || (X == 20 && Y == 13) || (X == 20 && Y == 14) || (X == 20 && Y == 15) || (X == 20 && Y == 16) || (X == 60 && Y == 10) || (X == 60 && Y == 11) || (X == 60 && Y == 12) || (X == 60 && Y == 13) || (X == 60 && Y == 14))
                {
                    GameOver();
                }
            }

            else if (level == 10)
            {
                if (X == Console.WindowWidth / border1 - border || X == 0 || Y == Console.WindowHeight / border1 - border || Y == 2 || (X == 5 && Y == 5) || (X == 5 && Y == 6) || (X == 5 && Y == 7) || (X == 5 && Y == 8) || (X == 5 && Y == 9) || (X == 5 && Y == 10) || (X == 5 && Y == 11) || (X == 5 && Y == 12) || (X == 5 && Y == 13) || (X == 5 && Y == 14) || (X == 5 && Y == 15) ||
                /* 54*/ (X == 5 && Y == 25) || (X == 5 && Y == 25) || (X == 6 && Y == 25) || (X == 7 && Y == 25) || (X == 8 && Y == 25) || (X == 9 && Y == 25) || (X == 10 && Y == 25) || (X == 11 && Y == 25) || (X == 12 && Y == 25) || (X == 13 && Y == 25) || (X == 14 && Y == 25) || (X == 15 && Y == 25) || (X == 16 && Y == 25) || (X == 17 && Y == 25) || (X == 18 && Y == 25) ||
                    (X == 19 && Y == 25) || (X == 20 && Y == 25) || (X == 21 && Y == 25) || (X == 22 && Y == 25) || (X == 23 && Y == 25) || (X == 24 && Y == 25) || (X == 25 && Y == 25) || (X == 26 && Y == 25) || (X == 27 && Y == 25) || (X == 28 && Y == 25) || (X == 29 && Y == 25) || (X == 30 && Y == 25) || (X == 31 && Y == 25) || (X == 32 && Y == 25) || (X == 32 && Y == 25) ||
                    (X == 33 && Y == 25) || (X == 34 && Y == 25) || (X == 35 && Y == 25) || (X == 36 && Y == 25) || (X == 37 && Y == 25) || (X == 38 && Y == 25) || (X == 39 && Y == 25) || (X == 40 && Y == 25) || (X == 41 && Y == 25) || (42 == 5 && Y == 25) || (43 == 5 && Y == 25) || (X == 44 && Y == 25) ||
                    (X == 45 && Y == 25) || (X == 46 && Y == 25) || (X == 47 && Y == 25) || (X == 48 && Y == 25) || (X == 49 && Y == 25) || (X == 50 && Y == 25) || (X == 51 && Y == 25) || (X == 52 && Y == 25) || (X == 53 && Y == 25) || (X == 54 && Y == 25) || (X == 70 && Y == 5) || (X == 70 && Y == 6) || (X == 70 && Y == 7) || (X == 70 && Y == 8) || (X == 70 && Y == 9) || (X == 70 && Y == 10) || (X == 70 && Y == 11) ||
                    (X == 70 && Y == 12) || (X == 70 && Y == 13) || (X == 70 && Y == 14) || (X == 70 && Y == 15))


                {
                    GameOver();
                }

            }
            else
            {
                if (X == Console.WindowWidth / border1 - border || X == 0 || Y == Console.WindowHeight / border1 - border || Y == 2)
                {
                    GameOver();
                }
            }

        }


        public void Congratulations()
        {
            Console.Clear();
            BorderIntro();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.SetCursorPosition((Console.WindowWidth / 2) - 22, Console.WindowHeight / 2 +1);

            Console.WriteLine("_______________CONGRATULATIONS______________");
            Console.ReadKey();
            Console.Beep(100, 700);
            
            
            LeaderBoard Lboard = new LeaderBoard();


            Console.SetCursorPosition(1, (Console.WindowHeight / 2) + 5);
            Lboard.addScore(Lboard.name("Enter your name: "), score);
            Lboard.check_file();


            Console.SetCursorPosition(1, (Console.WindowHeight / 2) + 7);
            Console.ForegroundColor = ConsoleColor.Gray;

            TryAgain();

        }


        public void GameOver()
        {
            Console.Beep(100, 700);
            Console.SetCursorPosition((Console.WindowWidth / 4) - 5, (Console.WindowHeight / 4) - 2);
            Console.WriteLine("Game Over!");
            Console.SetCursorPosition((Console.WindowWidth / 4) - 5, Console.WindowHeight / 4); //Score coordinates modifying
            Console.WriteLine("SCORE: {0} ", score);
            LeaderBoard Lboard = new LeaderBoard();


            Console.SetCursorPosition(90, (Console.WindowHeight / 2) + 1);
            Lboard.addScore(Lboard.name("Enter your name: "), score);
            Lboard.check_file();


            Console.SetCursorPosition(1, (Console.WindowHeight / 2) + 7);
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("Press enter to start a new game. Press escape to quit!");
            GameOverSelection();


        }
        public void GameOverSelection()
        {
            ConsoleKey helper = Console.ReadKey().Key;
            if (helper == ConsoleKey.Enter)
            {
                Start();
            }
            else if (helper == ConsoleKey.Escape)
            {
                Environment.Exit(0); // or also: proceed = false; key = ConsoleKey.Escape;
            }
            else // if the key isn't enter nor escape, the state persists
            {
                GameOverSelection();
            }
        }

        public void TryAgain()
        {
            Console.WriteLine("Would you like to try again?.\n Press R to Restart the Game\n Press Q to Quit");
            ConsoleKey helper = Console.ReadKey().Key;
            if (helper == ConsoleKey.R)
            {
                Start();
            }
            else if (helper == ConsoleKey.Q)
            {
                Environment.Exit(0); 
            }

        }

        public void SpeedY(int speed)
        {
            System.Threading.Thread.Sleep(speed);
        }
        public void SpeedX(int speed) // the x-axis has smaller space between characters = higher speed
        {
            System.Threading.Thread.Sleep(speed);

        }

        public void Start()
        {
            Console.Clear();
            BorderIntro();
            SegmentsCount = 1;
            score = 0;


            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.SetCursorPosition((Console.WindowWidth / 2) - 25, Console.WindowHeight / 2);

            Console.WriteLine("_____________SNAKE GAME By Group 8____________");
            Console.ReadKey();

            Console.Clear();
            LeaderBoard lboard = new LeaderBoard();
            lboard.Show();

            X = Console.WindowWidth / 4 - 1;
            Y = Console.WindowHeight / 4 - 1;
            Food(); // adding food
            Level_Snake lvl = new Level_Snake();
            lvl.Scene();// rendering the play Scene
            displayGameDetails(1, 0);


            Console.SetCursorPosition(X, Y); // cursor to the center depending on the size of the playground/Scene
            FirstInput();

        }
        public void FirstInput()
        {
            key = Console.ReadKey().Key;
            if (key != ConsoleKey.UpArrow && key != ConsoleKey.DownArrow && key != ConsoleKey.LeftArrow && key != ConsoleKey.RightArrow) //if input isn't any cursor arrow, the input getting is repeated
            {
                FirstInput();
            }
        }

        /*public void time() // DISPLAYS time
        {
            Console.SetCursorPosition((Console.WindowWidth / 2) - 2, 1);
            // Dito lalagay yung timer

            //Timer.Timers(seconds);
            //Console.WriteLine("     Time left: {0} ", seconds);
            //int numberofSeconds = 1;
            //Timer.Timers(numberofSeconds);
        }


        ///private static int _countDown = 30; // Seconds
        ///private static bool waySelected = false;

        ///static void OnTimedEvent(object source, ElapsedEventArgs e)
        //{

        //if (waySelected == false)
        //{
        //if (_countDown-- <= 0)
        //{
        //Console.WriteLine("Game Over");
        //GameOver();
        //Start();

        //}
        //else if (waySelected == true)
        //{
        //Console.SetCursorPosition((Console.WindowWidth / 2) - 2, 1);
        //Console.ForegroundColor = ConsoleColor.Yellow;
        //Console.WriteLine("Timer: " + _countDown);

        ///      }
        ///   }
        ///}*/
        #endregion Methods

        static void Main(string[] args)
        {
            Program prog = new Program();
            Forms winform = new Forms();
            Console.ReadKey();

            
            Forms.Forms1();
            prog.Start();

            while (proceed)
            {
                // for other loops, the parameters are the same, only the respective coordinate is added or subtracted
                /* if (key == ConsoleKey.DownArrow)
                 {
                     turnVertically("down");
                 }
                 else if (key == ConsoleKey.UpArrow)
                 {
                     turnVertically("up");
                 }
                 else if (key == ConsoleKey.LeftArrow)
                 {
                     turnHorizontally("left");
                 }
                 else if (key == ConsoleKey.RightArrow)
                 {
                     turnHorizontally("right");
                 } */

                while (key == ConsoleKey.DownArrow)
                {
                    prog.turnVertically("down");
                    if (!Console.KeyAvailable)
                    {
                        continue;
                    }
                    helper = Console.ReadKey().Key;
                    if (helper == ConsoleKey.RightArrow || helper == ConsoleKey.LeftArrow)
                    {
                        key = helper;
                        break;
                    }
                }
                while (key == ConsoleKey.UpArrow)
                {

                    prog.turnVertically("up");
                    if (!Console.KeyAvailable)
                    {
                        continue;
                    }
                    helper = Console.ReadKey().Key;
                    if (helper == ConsoleKey.RightArrow || helper == ConsoleKey.LeftArrow)
                    {
                        key = helper;
                        break;
                    }
                }
                while (key == ConsoleKey.RightArrow)
                {
                    prog.turnHorizontally("right");
                    if (!Console.KeyAvailable)
                    {
                        continue;
                    }
                    helper = Console.ReadKey().Key;
                    if (helper == ConsoleKey.UpArrow || helper == ConsoleKey.DownArrow)
                    {
                        key = helper;
                        break;
                    }
                }
                while (key == ConsoleKey.LeftArrow)
                {
                    prog.turnHorizontally("left");
                    if (!Console.KeyAvailable)
                    {
                        continue;
                    }
                    helper = Console.ReadKey().Key;
                    if (helper == ConsoleKey.UpArrow || helper == ConsoleKey.DownArrow)
                    {
                        key = helper;
                        break;
                    }
                }
            }
        }


        public void turnVertically(string keypress)
        {

            if (keypress == "up")
            {
                Y--;
            }
            else
            {
                Y++;
            }

            FoodEaten();
            if (score < 300)
            {

                Move(2, 2);
                SpeedY(150);
                
            }
            else if (score == 300 || score < 600)
            {

                Move(2, 0); //border ng play Scene lumalaki pinapaltan ung parameter
                SpeedY(140);

            }
            else if (score == 600 || score < 900)
            {
                Move(2, -1, 3);//level 3
                SpeedY(130);
            }
            else if (score == 900 || score < 1200)
            {
                Move(2, -5, 4);//level 4
                SpeedY(120);
            }
            else if (score == 1200 || score < 1600)
            {
                Move(2, -7, 5);//lavel 5
                SpeedY(110);
            }
            else if (score == 1600 || score < 2000) //level 6
            {
                Move(2, -9, 6);
                SpeedY(100);
            }
            else if (score == 2000 || score < 2400) // level 7
            {
                Move(2, -11, 7);
                SpeedY(90);
            }
            else if (score == 2400 || score < 2800) // level 8
            {
                Move(2, -11, 8);
                SpeedY(80);
            }
            else if (score == 2800 || score < 3200) // level 9// 
            {
                Move(2, -11, 9);
                SpeedY(70);
            }
            else if (score == 3200 || score < 3600) // level 10//
            {
                Move(2, -13, 10);
                SpeedY(60);
            }
            else if (score == 3600) // level 10//
            {
                FinishedGame.Congratulations();
                TryAgain();
            }


        }
        public void turnHorizontally(string keypress)
        {
            {
                if (keypress == "right")
                {
                    X++;
                }
                else
                {
                    X--;
                }

                FoodEaten();
                if (score < 300)
                {

                    /*bor.Border1(2, 2);*/
                    Move(2, 2);
                    SpeedX(150);
                    
                }
                else if (score == 300 || score < 600)
                {


                    Move(2, 0); // border ng playScene lumalaki pinapaltan ung parameter
                    SpeedX(140);

                }
                else if (score == 600 || score < 900) //level 3
                {
                    Move(2, -1, 3);//level 3

                    SpeedX(130);
                }
                else if (score == 900 || score < 1200) //level 4
                {
                    Move(2, -5, 4);
                    SpeedX(120);//level4
                }
                else if (score == 1200 || score < 1600) //level 5
                {
                    Move(2, -7, 5);//level5
                    SpeedX(110);
                }
                else if (score == 1600 || score < 2000) //level 6
                {
                    Move(2, -9, 6);
                    SpeedX(100);
                }
                else if (score == 2000 || score < 2400) // level 7
                {
                    Move(2, -10, 7);
                    SpeedX(90);
                }
                else if (score == 2400 || score < 2800) // level 8
                {
                    Move(2, -13, 8);
                    SpeedX(80);
                }
                else if (score == 2800 || score < 3200) // level 9 //
                {
                    Move(2, -15, 9);
                    SpeedX(70);
                }
                else if (score == 3200 || score < 3600) // level 10 //
                {
                    Move(2, -17, 10);
                    SpeedX(60);
                    
                }
                else if (score == 3600)
                {
                    
                    FinishedGame.Congratulations();
                    TryAgain();
                }
            }

        }
    }
}



