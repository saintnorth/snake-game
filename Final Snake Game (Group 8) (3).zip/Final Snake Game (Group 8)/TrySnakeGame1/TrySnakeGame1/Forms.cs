﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace SnakeGame_Group8_
{
    public class Forms
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        private static TextBox txtusername;
        public static void Forms1()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            Form a = new Form();
            a.StartPosition = FormStartPosition.CenterScreen;
            a.Text = "Snake Game Menu";
            a.Width = 500;
            a.Height = 500;
            a.ControlBox = false;
            Label lname = new Label();
            lname.Text = "Username: ";
            lname.Size = new System.Drawing.Size(60, 25);
            lname.Location = new System.Drawing.Point(20, 40);
            lname.Parent = a;
            txtusername = new TextBox();
            txtusername.Size = new System.Drawing.Size(300, 100);
            txtusername.Location = new System.Drawing.Point(100, 40);
            txtusername.Enabled = true;
            txtusername.Parent = a;
            Button btnshow = new Button();
            btnshow.Text = "S&tart";
            btnshow.Size = new System.Drawing.Size(100, 50);
            btnshow.Location = new System.Drawing.Point(100, 70);
            btnshow.Click += new System.EventHandler(btnShow_Click);
            btnshow.Parent = a;
            a.ShowDialog();

        }
        static void btnShow_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Welcome to the Snake Game, " + txtusername.Text + " Have fun!");
            Application.Exit();
        }

    }
    public class FinishedGame
    {
        public static void Congratulations()
        {
            Form congrats = new Form();
            congrats.Width = 500;
            congrats.Height = 500;
            congrats.ControlBox = false;
            MessageBox.Show("Congratulations you have finished the game!");
            
        }

    }
}
