﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SnakeGame_Group8_
{
    public class Level_Snake
    {
     
        // This Class whill havee all the levels. It can be use for main class to inherit.
        public void Scene() // creates the play Scene
        {


            //Dito yung lines ng border pero hindi siya nateterminate nakakin lang siya nung snake
            Console.ForegroundColor = ConsoleColor.Red;
            for (int x = 1; x < Console.WindowWidth / 2 - 1; x++)
            {
                Console.SetCursorPosition(x, Console.WindowHeight / 2 - 2); //writting bottom limit
                Console.Write("↔");
                Console.SetCursorPosition(x, 2);//writting top limit
                Console.Write("↔");



            }
            for (int y = 2; y < Console.WindowHeight / 2 - 1; y++)
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 - 1, y);//writting bottom limit
                Console.Write("↕");
                Console.SetCursorPosition(0, y);//writting top limit
                Console.Write("↕");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        public void Scene2() // creates the play Scene
        {

            //Dito yung lines ng border pero hindi siya nateterminate nakakin lang siya nung snake
            Console.ForegroundColor = ConsoleColor.Green;
            for (int x = 1; x < Console.WindowWidth / 2; x++)
            {
                Console.SetCursorPosition(x, Console.WindowHeight / 2 - 0); //writting bottom limit
                Console.Write("↔");
                Console.SetCursorPosition(x, 2);//writting top limit
                Console.Write("↔");
            }
            for (int y = 2; y < Console.WindowHeight / 2 + 1; y++)
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 - 0, y);//writting side limit
                Console.Write("|");
                Console.SetCursorPosition(0, y);//writting top limit
                Console.Write("|");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        public void Scene3()
        {

            //Dito yung lines ng border pero hindi siya nateterminate nakakin lang siya nung snake
            Console.ForegroundColor = ConsoleColor.White;

            Console.SetCursorPosition(30, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(31, 13);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(32, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(33, 11);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(34, 10);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(35, 9);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(36, 8);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(37, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(38, 6);//writting top limit
            Console.Write("*");



            for (int x = 1; x < Console.WindowWidth / 2 + 1; x++)
            {
                Console.SetCursorPosition(x, Console.WindowHeight - 14); //writting bottom limit
                Console.Write("↔");
                Console.SetCursorPosition(x, 2);//writting top limit
                Console.Write("↔");


            }
            for (int y = 2; y < Console.WindowHeight / 2 + 2; y++)
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 + 1, y);//writting right side limit
                Console.Write("|");
                Console.SetCursorPosition(0, y);//writting top limit
                Console.Write("|");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;



        }
        public void Scene4()
        {
            Console.SetCursorPosition(5, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(7, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(8, 6);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(12, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(13, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(14, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(15, 6);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(19, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(20, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(21, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(22, 6);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(32, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(33, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(34, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(35, 12);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(39, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(40, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(41, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(42, 12);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(46, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(47, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(48, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(49, 12);//writting top limit
            Console.Write("*");

            Console.ForegroundColor = ConsoleColor.Blue;
            for (int x = 1; x < Console.WindowWidth / 2 + 6; x++) // adding symbol to the right

            {
                Console.SetCursorPosition(x, Console.WindowHeight / 2 + 2); //writting bottom limit
                Console.Write("↔");
                Console.SetCursorPosition(x, 2);//writting top limit
                Console.Write("↔");


            }
            for (int y = 2; y < Console.WindowHeight / 2 + 3; y++)
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 + 6, y);//writting bottom limit move to riight ++
                Console.Write("|");
                Console.SetCursorPosition(0, y);//writting top limit
                Console.Write("|");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;


        }
        public void Scene5()
        {
            Console.SetCursorPosition(6, 5);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 8);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(6, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 13);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 15);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(6, 19);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 20);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 21);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 22);//writting top limit
            Console.Write("*");


            Console.SetCursorPosition(37, 18);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(38, 17);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(39, 16);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(40, 15);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(41, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(42, 13);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(43, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(44, 11);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(45, 10);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(46, 9);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(47, 8);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(48, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(49, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(50, 5);//writting top limit
            Console.Write("*");

            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            for (int x = 1; x < Console.WindowWidth / 2 + 9; x++)// adding symbol to the right

            {
                Console.SetCursorPosition(x, Console.WindowHeight / 2 + 7); //writting bottom limit // moving to the bottom
                Console.Write("↔");
                Console.SetCursorPosition(x, 2);//writting top limit
                Console.Write("↔");


            }
            for (int y = 2; y < Console.WindowHeight / 2 + 8; y++) // adding symbol to the right
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 + 8, y);//writting bottom limit move to the right
                Console.Write("|");
                Console.SetCursorPosition(0, y);//writting top limit
                Console.Write("|");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;


        }
        public void Scene6()
        {
            Console.SetCursorPosition(6, 5);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 8);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(6, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 13);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 15);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(6, 19);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 20);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 21);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 22);//writting top limit
            Console.Write("*");


            Console.SetCursorPosition(32, 18);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(33, 18);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(34, 18);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(35, 18);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(39, 18);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(40, 18);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(41, 18);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(42, 18);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(46, 18);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(47, 18);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(48, 18);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(49, 18);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(30, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(31, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(32, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(33, 7);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(38, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(39, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(40, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(41, 7);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(45, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(46, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(47, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(48, 7);//writting top limit
            Console.Write("*");

            Console.ForegroundColor = ConsoleColor.DarkCyan;
            for (int x = 1; x < Console.WindowWidth / 2 + 11; x++)// adding symbol to the right top

            {
                Console.SetCursorPosition(x, Console.WindowHeight / 2 + 10); //writting bottom limit // moving to the bottom
                Console.Write("↔");
                Console.SetCursorPosition(x, 2);//writting top limit
                Console.Write("↔");


            }
            for (int y = 2; y < Console.WindowHeight / 2 + 11; y++)// adding symbol to the right
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 + 10, y);//writting bottom limit // writing bottom limit to the right
                Console.Write("|");
                Console.SetCursorPosition(0, y);//writting top limit
                Console.Write("|");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        public void Scene7()
        {
            Console.SetCursorPosition(16, 17);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(18, 15);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(20, 13);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(22, 11);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(24, 9);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(26, 7);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(28, 5);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(35, 18);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(31, 18);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(27, 18);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(23, 18);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(19, 18);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(38, 17);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(40, 15);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(42, 13);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(44, 11);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(46, 9);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(48, 7);//writting top limit
            Console.Write("*");

            Console.SetCursorPosition(50, 5);//writting top limit
            Console.Write("*");

            Console.ForegroundColor = ConsoleColor.DarkGray;
            for (int x = 1; x < Console.WindowWidth / 2 + 13; x++)// adding symbol to the right top

            {
                Console.SetCursorPosition(x, Console.WindowHeight / 2 + 12); //writting bottom limit  // moving to the bottom
                Console.Write("↔");
                Console.SetCursorPosition(x, 2);//writting top limit
                Console.Write("↔");


            }
            for (int y = 2; y < Console.WindowHeight / 2 + 13; y++)// adding symbol to the right
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 + 12, y);//writting bottom limit // writing bottom limit to the right
                Console.Write("|");
                Console.SetCursorPosition(0, y);//writting top limit
                Console.Write("|");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
        public void Scene8()
        {

            {
                Console.SetCursorPosition(5, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(6, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(7, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(8, 6);//writting top limit
                Console.Write("*");

                Console.SetCursorPosition(12, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(13, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(14, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(15, 6);//writting top limit
                Console.Write("*");

                Console.SetCursorPosition(19, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(20, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(21, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(22, 6);//writting top limit
                Console.Write("*");
                //
                Console.SetCursorPosition(30, 14);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(31, 13);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(32, 12);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(33, 11);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(34, 10);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(35, 9);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(36, 8);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(37, 7);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(38, 6);//writting top limit
                Console.Write("*");

                //

                Console.SetCursorPosition(30, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(31, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(32, 6);//writting top limit
                Console.Write("*");
                Console.SetCursorPosition(33, 6);//writting top limit
                Console.Write("*");

                Console.ForegroundColor = ConsoleColor.DarkYellow;
                for (int x = 1; x < Console.WindowWidth / 2 + 14; x++)// adding symbol to the top

                {
                    Console.SetCursorPosition(x, Console.WindowHeight / 2 + 12); //writting bottom limit // moving to the bottom
                    Console.Write("↔");
                    Console.SetCursorPosition(x, 2);//writting top limit
                    Console.Write("↔");


                }
                for (int y = 2; y < Console.WindowHeight / 2 + 12; y++)// adding symbol ||
                {
                    Console.SetCursorPosition(Console.WindowWidth / 2 + 13, y);//writting bottom limit // moving th border to the right
                    Console.Write("|");
                    Console.SetCursorPosition(0, y);//writting top limit
                    Console.Write("|");
                }
                Console.ForegroundColor = ConsoleColor.Yellow;
            }
        }
        public void Scene9() ///////
        {
            Console.SetCursorPosition(30, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(31, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(32, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(33, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(34, 14);//writting top limit
            Console.Write("*");
            //
            Console.SetCursorPosition(20, 20);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(21, 21);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(22, 22);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(23, 23);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(24, 24);//writting top limit
            Console.Write("*");
            //
            Console.SetCursorPosition(10, 15);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(11, 15);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(12, 15);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(13, 15);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(14, 15);//writting top limit
            Console.Write("*");
            //
            Console.SetCursorPosition(10, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(10, 8);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(10, 9);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(10, 10);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(10, 11);//writting top limit
                                              //
            Console.SetCursorPosition(20, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(20, 13);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(20, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(20, 15);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(20, 16);//writting top limit

            //
            Console.SetCursorPosition(60, 10);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(60, 11);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(60, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(60, 13);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(60, 14);//writting top limit
            Console.Write("*");

            Console.ForegroundColor = ConsoleColor.DarkGray;
            for (int x = 1; x < Console.WindowWidth - 45; x++)

            {
                Console.SetCursorPosition(x, Console.WindowHeight - 4); //writting bottom limit
                Console.Write("↔");
                Console.SetCursorPosition(x, 2);//writting top limit
                Console.Write("↔");


            }
            for (int y = 2; y < Console.WindowHeight - 3; y++)
            {
                Console.SetCursorPosition(Console.WindowWidth - 45, y);//writting bottom limit
                Console.Write("|");
                Console.SetCursorPosition(0, y);//writting top limit
                Console.Write("|");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;

        }
        public void Scene10()//////
        {
            Console.SetCursorPosition(5, 5);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(5, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(5, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(5, 8);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(5, 9);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(5, 10);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(5, 11);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(5, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(5, 13);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(5, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(5, 15);//writting top limit
            Console.Write("*");
            //
            Console.SetCursorPosition(5, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(6, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(7, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(8, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(9, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(10, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(11, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(12, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(13, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(14, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(15, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(16, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(17, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(18, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(19, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(20, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(21, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(22, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(23, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(24, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(25, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(26, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(27, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(28, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(29, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(30, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(31, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(32, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(33, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(34, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(35, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(36, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(37, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(38, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(39, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(40, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(41, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(42, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(43, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(44, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(45, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(46, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(47, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(48, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(49, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(50, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(51, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(52, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(53, 25);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(54, 25);//writting top limit
            Console.Write("*");
            //
            Console.SetCursorPosition(70, 5);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(70, 6);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(70, 7);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(70, 8);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(70, 9);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(70, 10);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(70, 11);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(70, 12);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(70, 13);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(70, 14);//writting top limit
            Console.Write("*");
            Console.SetCursorPosition(70, 15);//writting top limit
            Console.Write("*");



            Console.ForegroundColor = ConsoleColor.DarkMagenta;
            for (int x = 1; x < Console.WindowWidth / 2 + 14; x++)

            {
                Console.SetCursorPosition(x, Console.WindowHeight / 2 + 13); //writting bottom limit
                Console.Write("↔");
                Console.SetCursorPosition(x, 2);//writting top limit
                Console.Write("↔");


            }
            for (int y = 2; y < Console.WindowHeight / 2 + 14; y++)
            {
                Console.SetCursorPosition(Console.WindowWidth / 2 + 13, y);//writting bottom limit
                Console.Write("|");
                Console.SetCursorPosition(0, y);//writting top limit
                Console.Write("|");
            }
            Console.ForegroundColor = ConsoleColor.Yellow;
        }
    }
}